import cv2
import mediapipe as mp
import math
import time
import pywhatkit as kit
import datetime
import threading
import geocoder


# Function to get the approximate live location using IP address
def get_live_location():
    g = geocoder.ip('me')
    return g.latlng

# Function to send a WhatsApp message with live location and screen image
def send_whatsapp_message(latitude, longitude, screen_image):
    print("Sending Message")
    current_time = datetime.datetime.now()
    location_link = f"https://www.google.com/maps?q={latitude},{longitude}"
    message = f"Assistance needed. Assistance asked at {current_time} at location {location_link}"

    # Save the screen image temporarily
    image_path = "screen_image.jpg"
    cv2.imwrite(image_path, screen_image)

    # Send the WhatsApp message with the image as the main photo and the message in the caption
    kit.sendwhats_image("+918235079275", image_path, caption=message)

# Initialize MediaPipe Face Detection and Hands modules
mp_face_detection = mp.solutions.face_detection
mp_hands = mp.solutions.hands

# Initialize the webcam
cap = cv2.VideoCapture(0)

# Set the desired frame width and height
cap.set(3, 1280)  # Width
cap.set(4, 720)   # Height

# Create a Face Detection object
face_detection = mp_face_detection.FaceDetection(min_detection_confidence=0.5)

# Create a Hands Detection object
hands = mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5)

# Initialize variables for gesture timing
thumbs_up_start_time = None
thumbs_up_duration = 0

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    # Detect faces in the frame
    results_face = face_detection.process(frame)

    # If faces are detected, draw bounding boxes around them
    if results_face.detections:
        for detection in results_face.detections:
            bboxC = detection.location_data.relative_bounding_box
            ih, iw, _ = frame.shape
            x, y, w, h = int(bboxC.xmin * iw), int(bboxC.ymin * ih), int(bboxC.width * iw), int(bboxC.height * ih)
            
            # Draw a square box around the face
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            # Capture the entire screen
            screen_image = frame.copy()

    # Detect thumbs-up gesture
    results_hands = hands.process(frame)

    if results_hands.multi_hand_landmarks:
        for landmarks in results_hands.multi_hand_landmarks:
            thumb_tip = landmarks.landmark[4]
            index_tip = landmarks.landmark[8]
            distance = ((thumb_tip.x - index_tip.x) ** 2 + (thumb_tip.y - index_tip.y) ** 2) ** 0.5
            thumb_up_threshold = 0.15

            if distance < thumb_up_threshold:
                if thumbs_up_start_time is None:
                    thumbs_up_start_time = time.time()
                else:
                    thumbs_up_duration = time.time() - thumbs_up_start_time
                    if thumbs_up_duration >= 3:  
                        # Obtain the live location
                        latitude, longitude = get_live_location()

                        # Start a thread to send a WhatsApp message with live location and screen image
                        threading.Thread(target=send_whatsapp_message, args=(latitude, longitude, screen_image.copy())).start()
                        thumbs_up_start_time = None
                        thumbs_up_duration = 0

                cv2.putText(frame, "Thumbs-Up", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            else:
                thumbs_up_start_time = None
                thumbs_up_duration = 0

            mp.solutions.drawing_utils.draw_landmarks(frame, landmarks, mp_hands.HAND_CONNECTIONS)

    cv2.imshow("Assistance Request", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
